package ch06homework.exam03_import.mycompany;

import ch06homework.exam03_import.hankook.SnowTire;
import ch06homework.exam03_import.hyndai.Engine;
import ch06homework.exam03_import.kumho.BigWidthTire;

public class Car {
	//�ʵ�
	Engine engine = new Engine();
	SnowTire tire1 = new SnowTire();
	BigWidthTire tire2 = new BigWidthTire();
	ch06homework.exam03_import.hankook.Tire tire3 = new ch06homework.exam03_import.hankook.Tire();
	ch06homework.exam03_import.kumho.Tire tire4 = new ch06homework.exam03_import.kumho.Tire();
}
