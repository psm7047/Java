package ch06homework.exam03_import.hankook;

public class Tire {}
