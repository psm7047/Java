package ch06homework.exam03_import.kumho;

public class Tire {}
